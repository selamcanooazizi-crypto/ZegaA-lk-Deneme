package com.zega.ai

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zega.ai.ai.EngineRegistry
import com.zega.ai.ai.EngineUnavailable
import com.zega.ai.data.Chat
import com.zega.ai.data.ChatMessage
import com.zega.ai.data.ChatRepository
import com.zega.ai.data.SettingsStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.UUID

class ZegaViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = ChatRepository(app)
    private val store = SettingsStore(app)

    var chats by mutableStateOf<List<Chat>>(emptyList())
        private set
    var currentId by mutableStateOf<String?>(null)
        private set
    var generating by mutableStateOf(false)
        private set

    var themeId by mutableStateOf(store.theme)
        private set
    var customColor by mutableIntStateOf(store.customColor)
        private set
    var language by mutableStateOf(store.language)
        private set

    private var job: Job? = null

    val currentChat: Chat? get() = chats.firstOrNull { it.id == currentId }

    init {
        chats = repo.load().sortedByDescending { it.updated }
    }

    // ---- settings ----
    fun setTheme(id: String) {
        themeId = id
        store.theme = id
    }

    fun setCustomColor(argb: Int) {
        customColor = argb
        store.customColor = argb
    }

    fun setLanguage(tag: String) {
        language = tag
        store.language = tag
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
    }

    // ---- chats ----
    fun newChat() {
        stop()
        currentId = null
    }

    fun selectChat(id: String) {
        stop()
        currentId = id
    }

    fun deleteChat(id: String) {
        if (id == currentId) {
            stop()
            currentId = null
        }
        chats = chats.filter { it.id != id }
        persist()
    }

    fun deleteAllChats() {
        stop()
        currentId = null
        chats = emptyList()
        persist()
    }

    fun storageBytes(): Long = repo.sizeBytes()

    fun stop() {
        job?.cancel()
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || generating) return
        val now = System.currentTimeMillis()
        val userMsg = ChatMessage(newId(), "user", t, now)

        val chatId: String
        val existing = currentId
        if (existing == null || chats.none { it.id == existing }) {
            chatId = newId()
            val title = t.replace('\n', ' ').take(40)
            chats = listOf(Chat(chatId, title, listOf(userMsg), now)) + chats
            currentId = chatId
        } else {
            chatId = existing
            mutate(chatId) { it.copy(messages = it.messages + userMsg, updated = now) }
            chats = chats.sortedByDescending { it.updated }
        }
        persist()

        val history = chats.first { it.id == chatId }.messages
        val assistantId = newId()
        generating = true
        job = viewModelScope.launch {
            var acc = ""
            try {
                EngineRegistry.active().generate(history).collect { token ->
                    acc += token
                    upsertAssistant(chatId, assistantId, acc, false)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: EngineUnavailable) {
                upsertAssistant(chatId, assistantId, e.code, true)
            } catch (e: Exception) {
                upsertAssistant(chatId, assistantId, "ERROR:" + (e.message ?: ""), true)
            } finally {
                generating = false
                persist()
            }
        }
    }

    private fun upsertAssistant(chatId: String, msgId: String, text: String, error: Boolean) {
        mutate(chatId) { c ->
            val msg = ChatMessage(msgId, "assistant", text, System.currentTimeMillis(), error)
            val exists = c.messages.any { it.id == msgId }
            c.copy(
                messages = if (exists) c.messages.map { if (it.id == msgId) msg else it } else c.messages + msg,
                updated = System.currentTimeMillis()
            )
        }
    }

    private fun mutate(id: String, f: (Chat) -> Chat) {
        chats = chats.map { if (it.id == id) f(it) else it }
    }

    private fun persist() {
        try {
            repo.save(chats)
        } catch (_: Exception) {
        }
    }

    private fun newId(): String = UUID.randomUUID().toString()
}
