package com.zega.ai.data

import android.content.Context

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("zega_settings", Context.MODE_PRIVATE)

    var theme: String
        get() = prefs.getString("theme", "BLACK") ?: "BLACK"
        set(value) {
            prefs.edit().putString("theme", value).apply()
        }

    var customColor: Int
        get() = prefs.getInt("custom_color", 0xFF2A1F4D.toInt())
        set(value) {
            prefs.edit().putInt("custom_color", value).apply()
        }

    /** BCP-47 tag. Turkish is the default language. */
    var language: String
        get() = prefs.getString("language", "tr") ?: "tr"
        set(value) {
            prefs.edit().putString("language", value).apply()
        }
}
