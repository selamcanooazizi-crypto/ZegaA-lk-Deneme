package com.zega.ai.ai

import com.zega.ai.data.ChatMessage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * Modular AI backend contract. Future engines (local GGUF / llama.cpp via JNI,
 * or a cloud API) implement this interface and are returned by [EngineRegistry].
 */
interface AiEngine {
    val id: String

    /** Streams the assistant reply token by token. Throws [EngineUnavailable] if it cannot run. */
    fun generate(history: List<ChatMessage>): Flow<String>
}

class EngineUnavailable(val code: String) : Exception(code)

/**
 * Stage 1 engine: no model is integrated yet, so it never invents an answer.
 * It reports honestly that no model is available.
 */
object NoModelEngine : AiEngine {
    override val id: String = "none"

    override fun generate(history: List<ChatMessage>): Flow<String> = flow {
        throw EngineUnavailable("NO_MODEL")
    }
}

object EngineRegistry {
    /** Replace/extend here when a real local or cloud engine is added. */
    fun active(): AiEngine = NoModelEngine
}
