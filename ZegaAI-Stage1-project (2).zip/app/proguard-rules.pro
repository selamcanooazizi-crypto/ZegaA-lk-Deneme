# ZegaAİ proguard rules (release minify is disabled in Stage 1)
